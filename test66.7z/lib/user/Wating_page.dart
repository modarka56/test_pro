import 'package:flutter/material.dart';

class Wating_page extends StatefulWidget {
  const Wating_page({Key? key}) : super(key: key);

  @override
  State<Wating_page> createState() => _Wating_pageState();
}

class _Wating_pageState extends State<Wating_page> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
