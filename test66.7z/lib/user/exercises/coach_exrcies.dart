import 'package:flutter/material.dart';

class coach_program extends StatefulWidget {
  const coach_program({Key? key}) : super(key: key);

  @override
  State<coach_program> createState() => _coach_programState();
}

class _coach_programState extends State<coach_program> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
